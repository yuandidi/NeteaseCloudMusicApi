# Installation
> `npm install --save @types/express-fileupload`

# Summary
This package contains type definitions for express-fileupload (https://github.com/richardgirges/express-fileupload#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/express-fileupload.

### Additional Details
 * Last updated: Thu, 06 Jan 2022 17:31:30 GMT
 * Dependencies: [@types/busboy](https://npmjs.com/package/@types/busboy), [@types/express](https://npmjs.com/package/@types/express)
 * Global values: none

# Credits
These definitions were written by [Gintautas Miselis](https://github.com/Naktibalda), [Sefa Ilkimen](https://github.com/silkimen), [Piotr Błażejewicz](https://github.com/peterblazejewicz), and [Mark Oude Elberink](https://github.com/markxoe).
