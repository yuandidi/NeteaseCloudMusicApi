# Installation
> `npm install --save @types/busboy`

# Summary
This package contains type definitions for busboy (https://www.npmjs.com/package/busboy).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/busboy/v0.

### Additional Details
 * Last updated: Thu, 06 Jan 2022 17:31:30 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [Jacob Baskin](https://github.com/jacobbaskin), and [BendingBender](https://github.com/BendingBender).
